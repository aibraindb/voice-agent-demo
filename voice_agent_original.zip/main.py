
import os
import asyncio
import websockets
import json
from fastapi import FastAPI, WebSocket
from dotenv import load_dotenv
from openai import OpenAI
from deepgram import DeepgramClient, LiveTranscriptionEvents, LiveOptions

load_dotenv()

DG_KEY = os.getenv("DEEPGRAM_API_KEY")
CLAUDE_KEY = os.getenv("ANTHROPIC_API_KEY")

dg_client = DeepgramClient(DG_KEY)
app = FastAPI()

@app.websocket("/ws/audio")
async def audio_stream(websocket: WebSocket):
    await websocket.accept()

    options = LiveOptions(
        model="nova-2",
        language="en-US",
        punctuate=True,
        encoding="linear16",
        channels=1,
        sample_rate=16000,
        interim_results=False
    )

    deepgram_socket = await dg_client.listen.live.v("1").transcribe(events=LiveTranscriptionEvents.ALL, options=options)

    @deepgram_socket.on(LiveTranscriptionEvents.Transcript)
    async def on_transcript(data, **kwargs):
        transcript = data.get("channel", {}).get("alternatives", [{}])[0].get("transcript", "")
        if transcript:
            print(f"User said: {transcript}")
            # Send to Claude (Anthropic)
            openai = OpenAI(api_key=CLAUDE_KEY)
            response = openai.chat.completions.create(
                model="claude-3-opus-20240229",
                messages=[
                    {"role": "user", "content": transcript}
                ]
            )
            reply = response.choices[0].message.content
            await websocket.send_text(reply)

    async def receive_audio():
        try:
            while True:
                data = await websocket.receive_bytes()
                await deepgram_socket.send(data)
        except:
            await deepgram_socket.finish()
            await websocket.close()

    await receive_audio()
