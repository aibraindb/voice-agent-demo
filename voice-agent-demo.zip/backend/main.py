import os
from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

origins = ["*"]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.websocket("/ws/audio")
async def audio_endpoint(websocket: WebSocket):
    await websocket.accept()
    await websocket.send_text("Voice agent connected. Start speaking.")
    while True:
        data = await websocket.receive_text()
        if data == "bye":
            break
        await websocket.send_text(f"You said: {data}")
    await websocket.close()